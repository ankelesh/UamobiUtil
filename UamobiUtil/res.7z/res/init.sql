create table users (
	id int primary key,
	name varchar(128),
	login varchar(32),
	passwd varchar(32)
);
